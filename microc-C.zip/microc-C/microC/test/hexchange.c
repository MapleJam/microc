void main() {
    // 测试二进制转换成十进制
    int a;
    a = hexchange("1111",2);
    print(a);      //输出对应的十进制 
    // 测试十六进制转换成十进制
    int b;
    b = hexchange("FFFF",16);
    print(b);     //输出对应的十进制 
  }