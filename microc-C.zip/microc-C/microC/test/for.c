// 测试for循环
void main (int n) {
  int i;
  i = 0;
  for( i; i<n; i=i+1){
    print(i);
  }
}