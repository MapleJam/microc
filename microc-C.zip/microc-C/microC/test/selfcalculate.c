void main(int n) {
    int a;
    a=100;
    a+=n;
    print(a);
    a=100;
    a-=n;
    print(a);
    a=100;
    a*=n;
    print(a);
    a=100;
    a/=n;
    print(a);
    a=100;
    a%=n;
    print(a);

}