// 测试switch-case
void main(int n) {
    switch( n ){
        case 1 : print(n);
        case 2 : print(n+1);
        default : print(-1);
    }
}   