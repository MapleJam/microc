// 测试Do Until
void main(int n) {
    int i;
    i=0;
    do{
        print(i);
        i=i+1;
    }until(i>n);
}