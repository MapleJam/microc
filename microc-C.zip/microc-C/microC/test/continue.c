//测试continue
void main(int n){
    int i;
    for(i=0;i<n;i++){
        if (i%2==0)
        {
            continue;
        }
        else{
            print(i);
        }
    }
}