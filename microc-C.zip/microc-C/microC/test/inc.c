// 测试自增
void main(int n){
    n = n++;         //测试n++
    print(n);
    n = ++n;         //测试++n
    print(n);
}