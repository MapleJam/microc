// 测试 bool
void main() {
  bool t;
  t = true;
  print(t);
  bool f;
  f = false;
  print(f);
}