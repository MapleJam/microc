// 测试三目运算
void main(int n){
    int i;
    i = n>0?1:0;      
    print(i);
}