
void main()
{
	int t;
	t = 1;
	{

        int a;
		a = 2;
		print a;
	}	
}
