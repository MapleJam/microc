// DoWhile测试
void main (int n) {
  int i;
  i = 0;
  do{
    print i;
    i = i +1;
  }while(i<n);
}