void main() {
    int i;
    for (i = 0; i < 5; i = i + 1)
    {
        print i;
    }
}