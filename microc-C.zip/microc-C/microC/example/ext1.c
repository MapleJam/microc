void main(int n) {
      print f(n,n);
 }

int f (int a,int b)
{
    return a + b ;
}