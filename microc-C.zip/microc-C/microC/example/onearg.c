void main(int n) {
}
