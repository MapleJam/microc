void main(int n) {
   g(n,n,n);
   return 3;
}

void g(int n,int m,int o){

return 8;
return 9;
}