
void main (){
int ia[2];
// *(ia+1) = 9 ;
ia[1] = 9;
print ia[1];
}

