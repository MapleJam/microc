int main(int n) {
    return 0;
}
