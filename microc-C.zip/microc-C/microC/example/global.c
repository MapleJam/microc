int m;
int main(int n) {
	m = n;
	//return m;
}
