void main(int n ) {
    while(n){
     print 1;
    }
}
