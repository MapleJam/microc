void main(int n) {
    int res;
    res = 5;
    n =  res * n + 3;
}
