int main(int n) {
    
    return g(n);
}
void g(int m){
    return 3;
}
