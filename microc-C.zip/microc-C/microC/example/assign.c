void main(int n) {
    n = 3;
}
