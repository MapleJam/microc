int main(int n) {
    return n;
}
