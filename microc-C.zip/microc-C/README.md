[2021-2022学年第2学期]

# [**实 验 报 告**]

![zucc](https://sigcc.gitee.io/xplatform/zucc.png)

- 课程名称: 编程语言原理与编译

- 实验项目: 期末大作业

- 专业班级: 计算机1903

- 学生学号: 31901076

- 学生姓名: 梅培杰

- 实验指导教师: 张芸

  ​

| 姓名   | 学号       | 班级      | 任务            | 权重   |
| ---- | -------- | ------- | ------------- | ---- |
| 梅培杰  | 31901076 | 计算机1903 | 编译器、解释器、测试、文档 | 1.0  |

代码提交日志：git老是报错，只能通过github网页手动上传文件

![000](.\img\000.png)

1. 项目自评等级:(1-5) 请根据自己项目情况填写下表

| 解释器            | 评分   | 难度   | 备注                |
| -------------- | ---- | ---- | ----------------- |
| for            | ⭐⭐⭐  | ⭐⭐⭐  | 实现for语句           |
| break          | ⭐⭐   | ⭐    | 实现了break          |
| continue       | ⭐⭐   | ⭐    | 实现了continue       |
| do while       | ⭐⭐⭐  | ⭐⭐   | 实现do while语句      |
| do  until      | ⭐⭐   | ⭐    | 实现do until语句      |
| 进制转换           | ⭐⭐   | ⭐⭐   | 实现进制转换            |
| Bool类型         | ⭐⭐   | ⭐⭐   | 实现Bool类型的定义       |
| 自增             | ⭐⭐   | ⭐⭐   | 实现自增操作            |
| 自减             | ⭐⭐   | ⭐⭐   | 实现 自减操作           |
| 三目运算           | ⭐⭐   | ⭐⭐   | 实现三目运算            |
| switch-case    | ⭐⭐   | ⭐⭐   | 实现switch-case     |
| +=、-=、*=、/=、%= | ⭐⭐   | ⭐⭐   | 实现了+=、-=、*=、/=、%= |
|                |      |      |                   |

| 编译器         | 评分   | 难度   | 备注             |
| ----------- | ---- | ---- | -------------- |
| for         | ⭐⭐⭐  | ⭐⭐⭐  | for循环          |
| do while    | ⭐⭐   | ⭐⭐   | do while语句     |
| do until    | ⭐⭐   | ⭐⭐   | do until 语句    |
| switch-case | ⭐⭐   | ⭐⭐   | 实现了switch-case |

项目说明

- 整体文件架构

  Absyn.fs              抽象语法

  CLex.fsl fslex      词法定义

  CPar.fsy              fsyacc语法定义

  Parse.fs              语法解析器

  Interp.fs              解释器

  interpc.fsproj       项目文件

  Contcomp.fs       编译器

  Machine.fs          指令定义

  microcc.fsproj     编译器项目文件

**解释器：**

dotnet restore interpc.fsproj //可选

dotnet clean interpc.fsproj //可选

dotnet build -v n interpc.fsproj //构建，-v n查看详细生成过程

./bin/Debug/net6.0/interpc.exe 测试的文件 参数

dotnet run -p interpc.fsproj 测试的文件 参数

dotnet run -p interpc.fsproj -g 测试的文件 参数 //显示token AST 等调试信息

**编译器：**

dotnet restore microcc.fsproj

dotnet clean microcc.fsproj

dotnet build microcc.fsproj //构建编译器

dotnet run -p microcc.fsproj 测试的文件 //执行编译器

./bin/Debug/net6.0/microcc.exe 测试的文件 //直接执行

解释器部分是基于现有代码 MICROC 的改进，在实现其他功能之前对原文件进行理解，经过不断地出错再不断地调试后，实现了若干功能如下：

/*在编写完新功能后需要重新构建编译器./bin/Debug/net6.0/interpc.exe
-v n查看详细生成过程 */
dotnet build -v n interpc.fsproj 

![001](.\img\001.png)

![002](.\img\002.png)



## 解释器的功能实现：

- For语句

  - Absyn.fs

    ```f#
      | For of expr * expr * expr * stmt (* For loop *)
    ```

  - CLex.fsl

    ```f#
      | "for"     -> FOR    
    ```

  - CPar.fsy

    ```f#
    %token FOR
    | FOR LPAR Expr SEMI Expr SEMI Expr RPAR StmtM    { For($3, $5, $7, $9)}
    ```

  - Interp.fs

    ```f#
    | For(expr1,expr2,expr3,body) -> 
            //定义 For循环辅助函数 loop
            let (res ,store0) = eval expr1 locEnv gloEnv store
            let rec loop store1 =
                //求值 循环条件,注意变更环境 store
                let (v, store2) = eval expr2 locEnv gloEnv store1
                    // 继续循环
                if v<>0 then  
                    let (reend ,store3) = eval expr3 locEnv gloEnv (exec body locEnv gloEnv store2)
                    loop store3
                else 
                    store2  
            loop store0
    ```

  - 测试

    ```c
    // 测试for循环
    void main (int n) {
      int i;
      i = 0;
      for( i=0; i<n; i=i+1){
        print(i);
      }
    }
    ```

    ![003](.\img\003.png)

- break

  - Absyn.fs

    ```F#
    | Break
    ```

  - CLex.fsl

    ```F#
    | "break"   -> BREAK
    ```

  - CPar.fsy

    ```F#
    %token  BREAK
    | BREAK SEMI                          { Break                }
    ```

  - Interp.fs

    ```F#
    | Break -> store
    ```

  - 测试

    ```c
    // 测试break
    void main(int n) {
        int i;
        i=0;
        for( i = 0 ; i < n;  i = i + 1){
            print(i);
            if(i>5){
              break;
            }
        }
    }
    ```

  ![004](.\img\004.png)

  continue

  - Absyn.fs

    ```F#
    | Continue
    ```

  - CLex.fsl

    ```f#
    | "continue"  -> CONTINUE
    ```

  - CPar.fsy

    ```f#
    %token CONTINUE
    | CONTINUE SEMI                       { Continue             }
    ```

  - Interp.fs

    ```f#
    | Continue -> store
    ```

  - 测试

    ```c
    //测试continue
    void main(int n){
        int i;
        for(i=0;i<n;i++){
            if (i%2==0)
            {
                continue;
            }
            else{
                print(i);
            }
        }
    }
    ```

  ![013](.\img\013.png)

  ​

- DoWhile语句

  - Absyn.fs

    ```f#
    | DoWhile of stmt * expr           (* DoWhile loop                *)
    ```

  - CLex.fsl
    ```f#
    | "do"      -> DO
    | "dowhile" -> DOWHILE
    ```

  - CPar.fsy

    ```f#
    %token DOWHILE DO
    | DO StmtM WHILE LPAR Expr RPAR SEMI  { DoWhile($2, $5)      }
    ```

  - Interp.fs

    ```f#
        | DoWhile (body, expr) -> 
            //定义 Do While循环辅助函数 loop
            let rec loop store1 = 
                //求值 循环条件,注意变更环境 store
                let (v, store2) = eval expr locEnv gloEnv store1
                // 判断条件是否满足，满足则继续循环
                if v <> 0 then 
                    loop (exec body locEnv gloEnv store2)
                else
                    store2  //退出循环返回 环境store2
            loop (exec body locEnv gloEnv store)
    ```

  - 测试DoWhile循环
    ```c
    // DoWhile测试
    void main (int n) {
      int i;
      i = 0;
      do{
        print(i);
        i = i +1;
      }while(i<n);
    }
    ```

    ![005](.\img\005.png)

- DoUntil语句

  - Absyn.fs

    ```f#
    | DoUntil of stmt * expr           (* DoUntil loop                *)
    ```

  - CLex.fsl

    ```f#
    | "dountil" -> DOUNTIL
    | "until"   -> UNTIL
    ```

  - CPar.fsy

    ```f#
    %token UNTIL DOUNTIL 
    | DO StmtM UNTIL LPAR Expr RPAR SEMI  { DoUntil($2, $5)        }
    ```

  - Interp.fs

    ```f#
    | DoUntil(body,e) -> 
        //定义 Do Until循环辅助函数 loop
          let rec loop store1 =
              //求值 循环条件,注意变更环境 store
                  let (v, store2) = eval e locEnv gloEnv store1
                  // 判断条件是否满足，满足就退出循环
                  if v=0 then 
                      loop (exec body locEnv gloEnv store2)
                  else 
                      store2
          loop (exec body locEnv gloEnv store)
    ```

  - 测试DoUntil

    ```c
    // 测试Do Until
    void main(int n) {
        int i;
        i=0;
       do{
            print(i);
            i=i+1;
       }until(i>n);
    }
    ```

​  ![006](.\img\006.png)

- 进制转换

  - 通过hexchange函数，将int类型十六进制数或二进制数转换成对应的十进制

  - Absyn.fs

    ```f#
    | HexChange of string * int        (* Hexchange                   *)
    ```

  - CLex.fsl

    ```f#
    | "hexchange" -> HEXCHANGE  
    ```

  - CPar.fsy

    ```f#
    | HEXCHANGE LPAR CSTSTRING COMMA CSTINT RPAR {HexChange($3,$5)     }
    ```

  - Interp.fs

    ```f#
          | HexChange(s,hex) ->
              let mutable res = 0;
              for i=0 to s.Length-1 do
                  if s.Chars(i)>='0' && s.Chars(i)<='9' then
                     res <- res*hex + ( (int (s.Chars(i)))-(int '0') )
                  elif s.Chars(i)>='a' && s.Chars(i)<='f' then
                     res <- res*hex + ( (int (s.Chars(i)))-(int 'a')+10 )
                  elif s.Chars(i)>='A' && s.Chars(i)<='F' then
                     res <- res*hex + ( (int (s.Chars(i)))-(int 'A')+10 )
                  else 
                     failwith("ERROR WORLD IN NUMBER")
              (res,store)
    ```

  - 测试进制转换

    ```c
    void main() {
        // 测试二进制转换成十进制
        int a;
        a = hexchange("1111",2);
        print(a);      //输出对应的十进制 
        // 测试十六进制转换成十进制
        int b;
        b = hexchange("FFFF",16);
        print(b);     //输出对应的十进制 
      }
    ```

    ![007](.\img\007.png)

  Bool类型

  - Absyn.fs

    ```f#
    | TypB                             (* Type bool                   *)   
    ```

  - CLex.fsl

    ```f#
    | "false"   -> CSTBOOL 0
    | "true"    -> CSTBOOL 1
    | "bool"    -> BOOL
    ```

  - CPar.fsy

    ```
    %token <int> CSTINT CSTBOOL  
    %token BOOL 
    ```


  - 测试,true返回1，false返回0

    ```c
    // 测试 bool
    void main() {
      bool t;
      t = true;
      print(t);
      bool f;
      f = false;
      print(f);
    }
    ```

​        ![008](.\img\008.png)

- 自增

  - Absyn.fs

    ```F#
    | Inc of access
    ```

  - CLex.fsl

    ```F#
    | "++"            { INC }
    ```

  - CPar.fsy

    ```F#
    | INC Access                          { Inc($2)             } //++i
    | Access INC                          { Inc($1)             } //i++
    ```

  - Interp.fs

    ```F#
    | Inc(acc)       -> let (loc, store1) = access acc locEnv gloEnv store
                            let (res) = getSto store1 loc
                            (res+1, setSto store1 loc (res+1)) 
                            
        let res =
            match ope with
            | "++"     -> i1+1      
    ```

  - 测试自增

    ```c
    // 测试自增
    void main(int n){
        n = n++;         //测试n++
        print(n);
        n = ++n;         //测试++n
        print(n);
    }
    ```

  ![009](.\img\009.png)


- 自减
  - Absyn.fs

    ```F#
    | Sub of access
    ```


  - CLex.fsl

    ```F#
    | "--"            { SUB }
    ```


  - CPar.fsy

    ```F#
    | SUB Access                          { Sub($2)             }
    | Access SUB                          { Sub($1)             }
    ```


  - Interp.fs

    ```F#
    | Sub(acc)      -> let (loc, store1) = access acc locEnv gloEnv store
                           let (res) = getSto store1 loc
                           (res-1, setSto store1 loc (res-1)) 
                           
            let res =
                match ope with
                | "--"     -> i1-1    
    ```


  - 测试自减

    ```c
    // 测试自减
    void main(int n){ 
        n = n--;       //测试n--
        print(n);
        n = --n;       //测试--n
        print(n);
    }
    ```

  ![010](.\img\010.png)

  三目运算

  - Absyn.fs

    ```f#
      | Prim3 of expr * expr * expr      
    ```

  - CLex.fsl

    ```f#
      | "?"             { QUE }
    ```

  - CPar.fsy

    ```f#
    %token QUE
    %right COLON QUE
    | Expr QUE Expr COLON Expr            { Prim3($1,$3,$5)     }
    ```

  - Interp.fs

    ```f#
        | Prim3( e1, e2 , e3) ->
            let (i1, store1) = eval e1 locEnv gloEnv store
            let (i2, store2) = eval e2 locEnv gloEnv store1
            let (i3, store3) = eval e3 locEnv gloEnv store2
            if i1 <> 0 then (i2,store3) 
                      else (i3,store3)  
    ```

  - 测试三目运算

    ```c
    // 测试三目运算
    void main(int n){
        int i;
        i = n>0?1:0;      
        print(i);
    }
    ```

  ![011](.\img\011.png)

  ​

- switch-case

  - Absyn.fs

    ```f#
      | Switch of expr * stmt list       (* Switch loop                 *)
      | Case of expr * stmt 
      | Default of stmt 
    ```

  - CLex.fsl

    ```f#
        | "switch"  -> SWITCH
        | "case"    -> CASE
        | "default" -> DEFAULT
    ```

  - CPar.fsy

    ```f#
    %token SWITCH CASE DEFAULT
    %token COLON

    | SWITCH LPAR Expr RPAR LBRACE CaseList RBRACE        { Switch($3,$6)  }

    ```

  - Interp.fs

    ```f#
    | Switch(e, body) ->
            let (v, store0) = eval e locEnv gloEnv store
            let rec carry list = 
                match list with
                | Case(e1, body1) :: next -> 
                    let (v1, store1) = eval e1 locEnv gloEnv store0
                    if v1 = v then exec body1 locEnv gloEnv store1
                    else carry next
                | Default(body) :: over ->
                    exec body locEnv gloEnv store0
                | [] -> store0
                | _ -> store0

            (carry body)

        | Case (e, body) -> exec body locEnv gloEnv store
        
        | Default(body) -> exec body locEnv gloEnv store
    ```

  - 测试switch-case

    ```c
    // 测试switch-case
    void main(int n) {
        switch( n ){
            case 1 : print(n);
            case 2 : print(n+1);
            default : print(6);
        }
    }      
    ```

![012](.\img\012.png)

+=、-=、*=、/=、%=

- Absyn.fs

  ```f#
    | Self of  access * string * expr
  ```

- CLex.fsl

  ```f#
    | "+="            { PLUSASSIGN }
    | "-="            { MINUSASSIGN }
    | "*="            { TIMESASSIGN }
    | "/="            { DIVASSIGN}
    | "%="            { MODASSIGN }
  ```

- CPar.fsy

  ```f#
  %token PLUSASSIGN MINUSASSIGN TIMESASSIGN DIVASSIGN MODASSIGN
  %left PLUSASSIGN MINUSASSIGN TIMESASSIGN DIVASSIGN MODASSIGN
  | Access PLUSASSIGN  Expr               { Self($1,"+",$3)     }
  | Access MINUSASSIGN Expr              { Self($1,"-",$3)     }
  | Access TIMESASSIGN  Expr              { Self($1,"*",$3)     }
  | Access DIVASSIGN  Expr                { Self($1,"/",$3)     }
  | Access MODASSIGN  Expr                { Self($1,"%",$3)     }
  ```

- Interp.fs

  ```f#
    | Self(acc,opt,e)-> let (loc, store1) = access acc locEnv gloEnv store
                          let (i1) = getSto store1 loc
                          let (i2, store2) = eval e locEnv gloEnv store
                          let res =
                            match opt with
                            | "*"  -> i1 * i2
                            | "+"  -> i1 + i2
                            | "-"  -> i1 - i2
                            | "/"  -> i1 / i2
                            | "%"  -> i1 % i2
                            | _    -> failwith ("unknown primitive " + opt)
                          (res, setSto store2 loc res)
  ```

- 测试+=、-=、*=、/=、%=

  ```c
  void main(int n) {
      int a;
      a=100;
      a+=n;
      print(a);
      a=100;
      a-=n;
      print(a);
      a=100;
      a*=n;
      print(a);
      a=100;
      a/=n;
      print(a);
      a=100;
      a%=n;
      print(a);

  }
  ```

![014](.\img\014.png)



## 编译器功能实现：

- For

  - Comp.fs

    ```f#
        | For(e1, e2, e3, body) ->         
          let labbegin = newLabel()
          let labtest  = newLabel()

          cExpr e1 varEnv funEnv @ [INCSP -1]
                @ [GOTO labtest; Label labbegin] 
                    @ cStmt body varEnv funEnv
                        @ cExpr e3 varEnv funEnv @ [INCSP -1]
                            @ [Label labtest] 
                                @ cExpr e2 varEnv funEnv 
                                    @ [IFNZRO labbegin]- 
    ```

  - 测试

    ```c
    void main() {
        int i;
        for (i = 0; i < 5; i = i + 1)
        {
            print i;
        }
    }

    ```

​             ![015](.\img\015.png)

- DoWhile

  - Comp.fs

    ```f#
        | DoWhile (body, e) ->
            let labbegin = newLabel ()
            let labtest = newLabel ()

            cStmt body varEnv funEnv
                @[ GOTO labtest]
                    @[Label labbegin ] 
                    @ cStmt body varEnv funEnv
                    @ [ Label labtest ] 
                    @ cExpr e varEnv funEnv 
                    @ [ IFNZRO labbegin ] 
    ```

  - 测试

    ```c
    // DoWhile测试
    void main (int n) {
      int i;
      i = 0;
      do{
        print i;
        i = i +1;
      }while(i<n);
    }
    ```

    ![016](.\img\016.png)

- DoUntil

  - Comp.fs

    ```f#
    | DoUntil (body, e) ->
            let labbegin = newLabel ()
            let labtest = newLabel ()

            cStmt body varEnv funEnv
                @[ GOTO labtest] 
                    @[Label labbegin ] 
                    @ cStmt body varEnv funEnv
                    @ [ Label labtest ] 
                    @ cExpr e varEnv funEnv  
                    @ [ IFZERO labbegin ]
    ```

  - 测试

    ```c
    // 测试Do Until
    void main(int n) {
        int i;
        i=0;
       do{
            print i;
            i=i+1;
       }until(i>n);
    }
    ```

    ![017](.\img\017.png)


- switch-case

  - Comp.fs

    ```f#
        | Switch (e, cases) ->
            let rec searchcases c =
                match c with
                | Case (e, body) :: tail ->
                    let labend = newLabel ()
                    let labfin = newLabel ()

                    [DUP]
                      @ cExpr e varEnv funEnv
                        @ [EQ]
                          @ [ IFZERO labend ]
                            @ cStmt body varEnv funEnv
                              @ [ GOTO labfin ]
                                @ [ Label labend ]
                                  @ searchcases tail
                                    @ [ Label labfin ]
                | Default body :: [] ->
                    cStmt body varEnv funEnv
                | [] -> []

            cExpr e varEnv funEnv 
              @ searchcases cases
                @[INCSP -1]
    ```

  - 测试

    ```c
    // 测试switch-case
    void main(int n) {
        switch( n ){
            case 1 : print(n);
            case 2 : print(n+1);
            default : print(6);
        }
    }
    ```

  ​       ![018](.\img\018.png)



- 心得体会（结合自己情况具体说明）

  刚开始，对大作业是一头雾水，面对这么多文件，不知道该如何处理，可以说是毫无头绪。后来请教了上一届的学长以及查找老师提供的相关资料，经过很长时间的学习，终于对该作业有了一些想法。其中Absyn.fs是定义类型和函数的，CLex.fsl是词法分析器，需要写一些关键字，定义完关键字就到语法分析器，CPar.fsy把定义好的关键字写在token里，然后再定义函数的表达式，最后在解释器或者编译器里写相应的代码来实现相关的功能。依据原有的一些函数实现方式，最终实现了一些功能。在此期间，git竟然是我最头疼的地方，时不时就会有莫名的错误，我应该要更加深入地学习一下。

  首先感谢老师这一学期细致的教学和无私的帮助，让我们感受到了编译原理的魅力。但是希望提高一下课堂互动效率，有助于加深我们对知识点的理解。教学过程中，在讲知识点的同时应该也要辅之代码实践，我相信这是这是很重要的，因为我们的coding能力还是需要提高。

  最后，再次对张芸老师以最诚挚的感谢！